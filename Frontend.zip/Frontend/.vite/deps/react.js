import {
  require_react
} from "./chunk-WNPTCGAH.js";
import "./chunk-5WRI5ZAA.js";
export default require_react();
//# sourceMappingURL=react.js.map
