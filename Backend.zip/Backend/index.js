import express from "express";
import cors from "cors";
import petfinderRouter from "./routes/petfinder.js";
import { notFound, errorHandler } from "./errors/middlewares.js";
import { ENV, envSummary } from "./config/env.js";

const app = express();
app.use(cors());
app.use(express.json());

// Debug: see envs being used (no secrets leaked, only lengths + previews)
app.get("/api/pf/health", (_req, res) => res.json({ ok: true, env: envSummary() }));

// Debug: attempt token and report Petfinder’s status/message (no secrets)
app.get("/api/pf/_debug/token", async (_req, res, next) => {
  try {
    const body = new URLSearchParams({
      grant_type: "client_credentials",
      client_id: ENV.PETFINDER_CLIENT_ID,
      client_secret: ENV.PETFINDER_CLIENT_SECRET,
    });

    const r = await fetch("https://api.petfinder.com/v2/oauth2/token", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body,
    });

    let text = await r.text().catch(() => "");
    let json; try { json = JSON.parse(text); } catch {}
    res.status(r.status).json({
      status: r.status,
      ok: r.ok,
      title: json?.title,
      detail: json?.detail || text,
      type: json?.type,
      received: !!json?.access_token ? "access_token" : "no_token",
      env: envSummary(),
    });
  } catch (e) {
    next(e);
  }
});



app.use("/api/pf", petfinderRouter);
app.use(notFound);
app.use(errorHandler);

app.listen(ENV.PORT, () =>
  console.log(`Backend listening on http://localhost:${ENV.PORT}`)
);
