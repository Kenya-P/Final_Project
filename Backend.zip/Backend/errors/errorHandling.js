export function problem({
  status = 500,
  title = 'Server Error',
  detail = '',
  type = 'about:blank',
  invalidParams, // array of { in, path, message }
  extra,         // anything else you want to attach (won't be sent by middleware)
} = {}) {
  const p = { type, title, status, detail };
  if (Array.isArray(invalidParams) && invalidParams.length) {
    p['invalid-params'] = invalidParams;
  }
  if (extra) p.extra = extra; // optional, useful for debugging
  return p;
}

// Wrap async route handlers so thrown/rejected errors go to Express error middleware
export const asyncHandler = (fn) => (req, res, next) =>
  Promise.resolve(fn(req, res, next)).catch(next);

// Convert any error into a {problem, status} pair the middleware understands
export function toProblem(err, fallback = {}) {
  if (err?.problem && typeof err.problem === 'object') {
    return { status: err.problem.status || 500, body: err.problem };
  }
  // Generic conversion (non-Problem errors)
  const status = err.status || fallback.status || 500;
  const body = problem({
    status,
    title: fallback.title || 'Unhandled Error',
    detail: (typeof err.message === 'string' && err.message) || fallback.detail || 'An unexpected error occurred.',
  });
  return { status, body };
}
