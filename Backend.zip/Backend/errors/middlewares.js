import { problem, toProblem } from './errorHandling.js';

export function notFound(_req, res, _next) {
  const body = problem({
    status: 404,
    title: 'Not Found',
    detail: 'The requested resource was not found.',
  });
  res.status(404).json(body);
}

// Final error handler — always responds with RFC-7807 JSON
export function errorHandler(err, _req, res, _next) {
  // You can log everything here
  // eslint-disable-next-line no-console
  console.error(err?.stack || err);

  const { status, body } = toProblem(err, {
    status: 500,
    title: 'Server Error',
    detail: 'An unexpected error occurred.',
  });

  // Optionally forward upstream rate-limit headers if they exist on the error
  if (err?.rate) {
    if (err.rate.limit) res.set('x-ratelimit-limit', err.rate.limit);
    if (err.rate.remaining) res.set('x-ratelimit-remaining', err.rate.remaining);
    if (err.rate.reset) res.set('x-ratelimit-reset', err.rate.reset);
  }

  res.status(status).json(body);
}
