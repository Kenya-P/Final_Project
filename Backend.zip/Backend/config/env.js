import dotenv from "dotenv";
import { fileURLToPath } from "url";
import path from "path";
import fs from "fs";

// Resolve absolute path to Backend/.env (works across branches & symlinks)
const __filename = fileURLToPath(import.meta.url);
const __dirname  = path.dirname(__filename);
const candidates = [
  path.resolve(__dirname, "..", ".env"),   // Backend/.env   ← expected
  path.resolve(__dirname, ".env"),         // Backend/config/.env
  path.resolve(process.cwd(), ".env"),     // CWD/.env
];

let loadedPath = null;
for (const p of candidates) {
  if (fs.existsSync(p)) {
    const res = dotenv.config({ path: p });
    if (!res.error) { loadedPath = p; break; }
  }
}

// Normalize + strip surrounding quotes if present
function clean(v) {
  if (v == null) return "";
  let s = String(v).trim();
  if ((s.startsWith('"') && s.endsWith('"')) || (s.startsWith("'") && s.endsWith("'"))) {
    s = s.slice(1, -1).trim();
  }
  return s;
}

function required(name) {
  const val = clean(process.env[name]);
  if (!val) throw new Error(`Missing required env: ${name}`);
  return val;
}

export const ENV = {
  PORT: clean(process.env.PORT) || "3001",
  PETFINDER_CLIENT_ID: required("PETFINDER_CLIENT_ID"),
  PETFINDER_CLIENT_SECRET: required("PETFINDER_CLIENT_SECRET"),
};

export function envSummary() {
  return {
    loadedPath,
    PORT: ENV.PORT,
    PETFINDER_CLIENT_ID_present: !!ENV.PETFINDER_CLIENT_ID,
    PETFINDER_CLIENT_ID_len: ENV.PETFINDER_CLIENT_ID.length,
    PETFINDER_CLIENT_SECRET_present: !!ENV.PETFINDER_CLIENT_SECRET,
    PETFINDER_CLIENT_SECRET_len: ENV.PETFINDER_CLIENT_SECRET.length,
    // mask/preview (first/last 4 chars) — helpful to spot wrong keys
    PETFINDER_CLIENT_ID_preview: ENV.PETFINDER_CLIENT_ID.replace(/^(.{0,4}).*(.{0,4})$/, "$1…$2"),
    PETFINDER_CLIENT_SECRET_preview: ENV.PETFINDER_CLIENT_SECRET.replace(/^(.{0,4}).*(.{0,4})$/, "$1…$2"),
  };
}
