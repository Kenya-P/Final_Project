router.get('/animals', async (req, res) => {
  try {
    const tokenRes = await axios.get('http://localhost:3001/api/petfinder/token');
    const token = tokenRes.data.access_token;

    const result = await axios.get('https://api.petfinder.com/v2/animals?type=dog', {
      headers: {
        Authorization: `Bearer ${token}`
      }
    });

    res.json(result.data);
  } catch (err) {
    console.error(err.response?.data || err.message);
    res.status(500).json({ error: 'Failed to fetch animals' });
  }
});
