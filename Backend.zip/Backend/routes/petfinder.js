import { Router } from "express";
import { asyncHandler, problem } from "../errors/errorHandling.js";
import { ENV } from "../config/env.js";

const router = Router();

let accessToken = null;
let tokenExp = 0; // unix seconds

async function ensureToken() {
  const now = Math.floor(Date.now() / 1000);
  if (accessToken && now < tokenExp - 60) return accessToken;

  const body = new URLSearchParams({
    grant_type: "client_credentials",
    client_id: ENV.PETFINDER_CLIENT_ID,
    client_secret: ENV.PETFINDER_CLIENT_SECRET,
  });

  const res = await fetch("https://api.petfinder.com/v2/oauth2/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body,
  });

  if (!res.ok) {
    let txt = await res.text().catch(() => "");
    let json; try { json = JSON.parse(txt); } catch {}
    const err = new Error("Token fetch failed");
    err.problem = problem({
      status: res.status,                       // <- 401 will flow through
      title: json?.title || "Authentication Failed",
      detail: json?.detail || txt || res.statusText,
      type: json?.type,
    });
    throw err;
  }

  const data = await res.json();
  accessToken = data.access_token;
  tokenExp = Math.floor(Date.now() / 1000) + (data.expires_in ?? 3600);
  return accessToken;
}

async function pfFetch(path, params = {}) {
  const token = await ensureToken();
  const url = new URL(`https://api.petfinder.com/v2${path}`);
  for (const [k, v] of Object.entries(params)) {
    if (v != null && String(v).trim() !== "") url.searchParams.set(k, v);
  }
  const res = await fetch(url, { headers: { Authorization: `Bearer ${token}` } });

  if (!res.ok) {
    let txt = await res.text().catch(() => "");
    let json; try { json = JSON.parse(txt); } catch {}
    const err = new Error(`Upstream error ${res.status}`);
    err.problem = problem({
      status: res.status,
      title: json?.title || res.statusText,
      detail: json?.detail || txt || "Petfinder request failed.",
      type: json?.type,
      invalidParams: json?.["invalid-params"],
    });
    throw err;
  }
  return res.json();
}

router.get("/types", asyncHandler(async (_req, res) => {
  const data = await pfFetch("/types");
  res.json({ types: data.types ?? [] });
}));

router.get("/animals", asyncHandler(async (req, res) => {
  const data = await pfFetch("/animals", req.query);
  res.json({ animals: data.animals ?? [], pagination: data.pagination ?? {} });
}));

export default router;


